import AllOrNothing from './src/components/AllorNothing.jsx';


test('clickhandler alert runs onClick', () => {

});