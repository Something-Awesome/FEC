import React from 'react';


const sameLine = {
  float: 'left',
  textAlign: 'left'
};

export { sameLine };