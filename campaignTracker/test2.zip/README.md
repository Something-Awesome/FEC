# FEC

Navigate to proxy:
npm start

Navigate to campaignTracker:
npm start (runs server)
npm react-dev (runs webpack -- open new terminal window)