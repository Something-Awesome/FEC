const pledges = {
  totalBackers: 79,
  totalPledged: 77000
};

export default pledges;