import React from 'react';

const RemindMe = props => {
  return (
    <div>
      {console.log('remindme')}
      <button>Remind Me</button>
    </div>
  );
};

export default RemindMe;